# MCSM Cinematic Movement Engine (Fabric 1.20.1, VR-only)

## Build
Needs JDK 17 and Gradle 8.6+ (one-time: `gradle wrapper --gradle-version 8.8`).
    ./gradlew build        ->  build/libs/climbmod-1.0.0.jar

## Install
- Client (VR): Fabric Loader, Fabric API, Vivecraft + this jar.
- Dedicated server: Fabric Loader, Fabric API + this jar. Vivecraft NOT needed.
  (Server validates climb packets and rebroadcasts sound/particles only.)

## Notes
- Movement features only activate on clients where Vivecraft is running.
- Beam entity id: edit config/climbmod.properties after first launch.
- Client-only code lives in com.example.climbmod.client. Common code talks to it
  only through ClimbBridge (no-op on servers).
