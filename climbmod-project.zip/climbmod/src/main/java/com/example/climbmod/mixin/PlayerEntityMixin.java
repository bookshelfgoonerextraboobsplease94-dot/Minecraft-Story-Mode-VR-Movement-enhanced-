package com.example.climbmod.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.example.climbmod.BeamDetector;
import com.example.climbmod.ClimbMod;
import com.example.climbmod.LedgeScanner;
import com.example.climbmod.ClimbBridge;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * MCSM Cinematic Movement Engine - the single physics mixin.
 *
 * Authority model (important for VR smoothness):
 *  - The CONTROLLING CLIENT runs all movement physics (beam swim, latch, ascent, mantle) because
 *    vanilla already treats the client as authoritative for its own position. No server-side
 *    velocity is ever applied, so there is nothing to rubber-band against.
 *  - The SERVER only validates: it re-detects the beam itself, trusts a short-lived "climbing" flag
 *    fed by sanity-checked packets, and resets fall distance + the vanilla anti-fly counter.
 *  - REMOTE players on a client only run the beam detection so their swim pose does not flicker.
 *
 * Priority 1: Wither Storm tractor beam swim. Priority 2: ledge latch / ascent / mantle.
 */
@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin extends LivingEntity {

    @Unique private ClimbMod.Phase climbmod$phase = ClimbMod.Phase.NONE;
    @Unique private int climbmod$climbTicks = 0;
    @Unique private int climbmod$cooldownTicks = 0;
    @Unique private BlockPos climbmod$lastWallPos = BlockPos.ORIGIN;
    /** Direction locked at latch time so turning your head in VR does not drop the grip. */
    @Unique private Direction climbmod$climbFacing = Direction.NORTH;
    /** Ledge height captured when the mantle starts (the wall column is not re-scanned mid-mantle). */
    @Unique private double climbmod$mantleTopY = 0.0;
    /** Horizontal speed measured while NOT colliding (collision zeroes velocity before our next tick). */
    @Unique private double climbmod$recentHorizSpeed = 0.0;
    /** Beam result cached once per tick so updateSwimming does not repeat the entity query. */
    @Unique private boolean climbmod$inBeam = false;

    protected PlayerEntityMixin(EntityType<? extends LivingEntity> entityType, World world) {
        super(entityType, world);
    }

    // =====================================================================
    // Tick: state decisions (both sides)
    // =====================================================================

    @Inject(method = "tick", at = @At("HEAD"))
    private void climbmod$tick(CallbackInfo ci) {
        PlayerEntity player = (PlayerEntity) (Object) this;
        World world = player.getWorld();

        if (climbmod$cooldownTicks > 0) {
            climbmod$cooldownTicks--;
        }

        // VR-exclusive: a non-VR local client gets vanilla movement, untouched.
        if (world.isClient && ClimbBridge.isLocal(player) && !ClimbBridge.isVrActive()) {
            climbmod$inBeam = false;
            climbmod$resetClimbState();
            return;
        }

        boolean clientLocal = world.isClient && ClimbBridge.isLocal(player);
        boolean server = !world.isClient;

        // ---- Priority 1: Wither Storm beam (all players, both sides, pose only for non-local) ----
        climbmod$inBeam = !player.isSpectator()
                && !player.getAbilities().flying
                && BeamDetector.isInBeam(player);

        if (climbmod$inBeam) {
            climbmod$resetClimbState();
            player.setSwimming(true);
            player.fallDistance = 0.0F;
            if (server && player instanceof ServerPlayerEntity serverPlayer) {
                climbmod$resetAntiFly(serverPlayer);
            }
            return; // physics for the local player runs in travel()
        }

        // ---- Priority 2: ledge engine ----
        if (clientLocal) {
            climbmod$clientClimbTick(player);
        } else if (server && player instanceof ServerPlayerEntity serverPlayer
                && ClimbMod.isServerClimbing(serverPlayer)) {
            // Server validation only: no velocity, just forgiveness.
            player.fallDistance = 0.0F;
            climbmod$resetAntiFly(serverPlayer);
        }
    }

    // =====================================================================
    // Travel: replaces vanilla movement for the local player while beam-swimming / latched / mantling
    // =====================================================================

    @Inject(method = "travel", at = @At("HEAD"), cancellable = true)
    private void climbmod$travel(Vec3d movementInput, CallbackInfo ci) {
        PlayerEntity player = (PlayerEntity) (Object) this;
        if (!player.getWorld().isClient || !ClimbBridge.isLocal(player)) {
            return;
        }

        if (climbmod$inBeam) {
            player.setVelocity(climbmod$computeBeamVelocity(player));
            player.move(MovementType.SELF, player.getVelocity());
            ci.cancel(); // no gravity, no ground/air friction, no vanilla input acceleration
        } else if (climbmod$phase != ClimbMod.Phase.NONE) {
            // Velocity was decided in tick(); moving here with no gravity gives a deterministic climb.
            player.move(MovementType.SELF, player.getVelocity());
            ci.cancel();
        }
    }

    /** Keeps vanilla from resetting the swimming flag outside of water while in the beam. */
    @Inject(method = "updateSwimming", at = @At("HEAD"), cancellable = true)
    private void climbmod$keepBeamSwimPose(CallbackInfo ci) {
        if (climbmod$inBeam) {
            ((PlayerEntity) (Object) this).setSwimming(true);
            ci.cancel();
        }
    }

    // =====================================================================
    // Beam swim (client physics)
    // =====================================================================

    /**
     * Full 3D swim: forward/back follows the look vector INCLUDING pitch, strafe follows the
     * horizontal right vector, jump rises, sneak sinks. Accelerate, drag, clamp.
     */
    @Unique
    private Vec3d climbmod$computeBeamVelocity(PlayerEntity player) {
        Vec3d look = player.getRotationVec(1.0F);
        Vec3d right = look.crossProduct(new Vec3d(0.0, 1.0, 0.0)).normalize();

        double forward = Math.signum(ClimbBridge.getMoveForward());
        double left = Math.signum(ClimbBridge.getMoveSideways()); // + = left

        Vec3d wish = Vec3d.ZERO;
        if (forward != 0.0) {
            wish = wish.add(look.multiply(forward));
        }
        if (left != 0.0) {
            wish = wish.add(right.multiply(-left));
        }
        if (ClimbBridge.isJumpHeld()) {
            wish = wish.add(0.0, 1.0, 0.0);
        }
        if (ClimbBridge.isSneakHeld()) {
            wish = wish.add(0.0, -1.0, 0.0);
        }

        Vec3d velocity = player.getVelocity();
        if (wish.lengthSquared() > 1.0E-6) {
            velocity = velocity.add(wish.normalize().multiply(BeamDetector.SWIM_ACCEL));
        }
        velocity = velocity.multiply(BeamDetector.SWIM_DRAG);
        if (velocity.length() > BeamDetector.SWIM_MAX_SPEED) {
            velocity = velocity.normalize().multiply(BeamDetector.SWIM_MAX_SPEED);
        }
        return velocity;
    }

    // =====================================================================
    // Ledge engine (client physics + immediate local feedback)
    // =====================================================================

    @Unique
    private void climbmod$clientClimbTick(PlayerEntity player) {
        if (!climbmod$canClimb(player)) {
            if (climbmod$phase != ClimbMod.Phase.NONE) {
                climbmod$release(true);
            }
            return;
        }

        // ---------------- NONE: look for a latch ----------------
        if (climbmod$phase == ClimbMod.Phase.NONE) {
            Vec3d vel = player.getVelocity();
            if (!player.horizontalCollision) {
                climbmod$recentHorizSpeed = Math.sqrt(vel.x * vel.x + vel.z * vel.z);
            }
            if (climbmod$cooldownTicks == 0 && !player.isOnGround() && player.horizontalCollision
                    && climbmod$recentHorizSpeed >= ClimbMod.MIN_IMPACT_SPEED) {
                Direction facing = player.getHorizontalFacing();
                LedgeScanner.WallHit hit = LedgeScanner.scan(player, facing);
                if (hit != null && hit.hasStandingRoom()) {
                    climbmod$phase = ClimbMod.Phase.LATCHED;
                    climbmod$climbTicks = 0;
                    climbmod$climbFacing = facing;
                    climbmod$lastWallPos = hit.wallPos();
                    climbmod$feedback(player, ClimbMod.Event.LATCH, hit.wallPos());
                }
            }
        }

        // ---------------- LATCHED ----------------
        if (climbmod$phase == ClimbMod.Phase.LATCHED) {
            LedgeScanner.WallHit hit = LedgeScanner.scan(player, climbmod$climbFacing);
            if (hit == null || !hit.hasStandingRoom() || player.isOnGround()
                    || ClimbBridge.isSneakHeld()) {
                climbmod$release(true);
                return;
            }
            climbmod$lastWallPos = hit.wallPos();
            player.fallDistance = 0.0F;

            boolean jump = ClimbBridge.isJumpHeld();
            double y = ClimbMod.LATCH_SLIDE_SPEED;
            if (jump) {
                y = ClimbMod.ASCENT_SPEED;
                climbmod$climbTicks++;
                if (climbmod$climbTicks % ClimbMod.CLIMB_STEP_INTERVAL == 0) {
                    climbmod$feedback(player, ClimbMod.Event.STEP, hit.wallPos());
                }
            }
            // Gentle press into the wall keeps horizontalCollision true without any drift.
            player.setVelocity(climbmod$climbFacing.getOffsetX() * ClimbMod.WALL_PRESS_SPEED, y,
                    climbmod$climbFacing.getOffsetZ() * ClimbMod.WALL_PRESS_SPEED);

            double distanceToTop = hit.ledgeTopY() - player.getY();
            if (jump && distanceToTop <= ClimbMod.MANTLE_TRIGGER_BELOW_TOP) {
                climbmod$phase = ClimbMod.Phase.MANTLING;
                climbmod$climbTicks = 0;
                climbmod$mantleTopY = hit.ledgeTopY();
                climbmod$feedback(player, ClimbMod.Event.MANTLE, hit.wallPos());
                if (ClimbMod.CAMERA_SHAKE_ENABLED) {
                    ClimbBridge.triggerShake(ClimbMod.SHAKE_STRENGTH);
                }
            } else if (climbmod$climbTicks % ClimbMod.HEARTBEAT_INTERVAL == 0 || !jump) {
                // Keep the server flag alive (also while hanging without pressing jump).
                if (player.age % ClimbMod.HEARTBEAT_INTERVAL == 0) {
                    ClimbBridge.sendEvent(ClimbMod.Event.HEARTBEAT, hit.wallPos());
                }
            }
            return;
        }

        // ---------------- MANTLING (no re-scan: the wall column ends under our feet) ----------------
        if (climbmod$phase == ClimbMod.Phase.MANTLING) {
            player.fallDistance = 0.0F;
            climbmod$climbTicks++;

            Direction dir = climbmod$climbFacing;
            // Rise fast, but never overshoot: hover just above the lip while sliding forward onto it.
            double remaining = climbmod$mantleTopY - player.getY() + 0.05;
            double y = Math.min(ClimbMod.MANTLE_UP_SPEED, Math.max(0.0, remaining));
            player.setVelocity(dir.getOffsetX() * ClimbMod.MANTLE_FORWARD_SPEED, y,
                    dir.getOffsetZ() * ClimbMod.MANTLE_FORWARD_SPEED);

            if (player.age % ClimbMod.HEARTBEAT_INTERVAL == 0) {
                ClimbBridge.sendEvent(ClimbMod.Event.HEARTBEAT, climbmod$lastWallPos);
            }

            // Distance of the player's centre past the wall plane, along the facing axis.
            double planeX = climbmod$lastWallPos.getX() + (dir.getOffsetX() < 0 ? 1 : 0);
            double planeZ = climbmod$lastWallPos.getZ() + (dir.getOffsetZ() < 0 ? 1 : 0);
            double depth = dir.getOffsetX() * (player.getX() - planeX)
                    + dir.getOffsetZ() * (player.getZ() - planeZ);
            boolean levelWithLedge = player.getY() >= climbmod$mantleTopY - 0.01;

            if ((levelWithLedge && depth >= ClimbMod.MANTLE_COMPLETE_DEPTH)
                    || climbmod$climbTicks >= ClimbMod.MAX_MANTLE_TICKS) {
                climbmod$release(false);
                climbmod$cooldownTicks = ClimbMod.MANTLE_COOLDOWN_TICKS;
            }
        }
    }

    /** Conditions under which the ledge engine must not run at all. */
    @Unique
    private boolean climbmod$canClimb(PlayerEntity player) {
        return !player.isSpectator()
                && !player.getAbilities().flying
                && !player.hasVehicle()
                && !player.isTouchingWater()
                && !player.isInLava()
                && !player.isFallFlying()
                && !player.isClimbing();
    }

    /** Immediate local sound + particles, then tell the server so it can rebroadcast to others. */
    @Unique
    private void climbmod$feedback(PlayerEntity player, ClimbMod.Event event, BlockPos wallPos) {
        ClimbBridge.playLocalFeedback(player, wallPos, event);
        ClimbBridge.sendEvent(event, wallPos);
    }

    /** Ends the climb. {@code notifyServer} sends RELEASE so the server drops its flag immediately. */
    @Unique
    private void climbmod$release(boolean applyCooldown) {
        if (applyCooldown && climbmod$phase != ClimbMod.Phase.NONE) {
            climbmod$cooldownTicks = ClimbMod.RELEASE_COOLDOWN_TICKS;
        }
        if (climbmod$phase != ClimbMod.Phase.NONE) {
            ClimbBridge.sendEvent(ClimbMod.Event.RELEASE, climbmod$lastWallPos);
        }
        climbmod$phase = ClimbMod.Phase.NONE;
        climbmod$climbTicks = 0;
    }

    /** Silent reset used when the beam takes over (no packet; the server detects the beam itself). */
    @Unique
    private void climbmod$resetClimbState() {
        climbmod$phase = ClimbMod.Phase.NONE;
        climbmod$climbTicks = 0;
    }

    /** Clears vanilla's "floating too long" kick counter so hanging on a wall is not flagged as flying. */
    @Unique
    private void climbmod$resetAntiFly(ServerPlayerEntity player) {
        ServerPlayNetworkHandler handler = player.networkHandler;
        if (handler != null) {
            ((ServerPlayNetworkHandlerAccessor) handler).climbmod$setFloatingTicks(0);
        }
    }
}
