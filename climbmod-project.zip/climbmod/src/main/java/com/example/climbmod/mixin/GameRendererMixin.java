package com.example.climbmod.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.example.climbmod.client.ClimbClientBridge;

import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "renderWorld", at = @At("HEAD"), require = 0)
    private void climbmod$shake(float tickDelta, long limitTime, MatrixStack matrices, CallbackInfo ci) {
        float roll = ClimbClientBridge.getShakeRoll(tickDelta);
        if (roll != 0.0F) {
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(roll));
        }
    }
}
