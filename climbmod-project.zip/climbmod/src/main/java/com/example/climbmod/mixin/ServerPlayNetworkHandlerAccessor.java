package com.example.climbmod.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import net.minecraft.server.network.ServerPlayNetworkHandler;

/**
 * Exposes vanilla's "floating too long" counter (1.20.1 Yarn: floatingTicks) so the server can
 * zero it while a player hangs on a wall or swims in the beam. Without this, vanilla kicks
 * players for "flying" after ~80 ticks of not touching the ground.
 */
@Mixin(ServerPlayNetworkHandler.class)
public interface ServerPlayNetworkHandlerAccessor {

    @Accessor("floatingTicks")
    void climbmod$setFloatingTicks(int ticks);
}
