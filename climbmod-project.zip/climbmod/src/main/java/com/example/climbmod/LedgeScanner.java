package com.example.climbmod;

import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/** Scans the wall column in front of the player for a climbable ledge. */
public final class LedgeScanner {

    /** Highest ledge (blocks above the player's feet) that can be latched onto. */
    private static final int MAX_REACH = 8;

    /**
     * @param wallPos     solid block next to the player (used for sound/particles + server validation)
     * @param ledgeTopY   world Y of the walkable surface on top of the wall
     * @param hasStandingRoom true if the player fits on top of the ledge
     */
    public record WallHit(BlockPos wallPos, double ledgeTopY, boolean hasStandingRoom) {
    }

    private LedgeScanner() {
    }

    @Nullable
    public static WallHit scan(PlayerEntity player, Direction facing) {
        if (facing.getAxis().isVertical()) {
            return null;
        }
        World world = player.getWorld();
        BlockPos feet = BlockPos.ofFloored(player.getX(), player.getY(), player.getZ());
        BlockPos column = feet.offset(facing);

        // Find the first solid wall block at feet or head height.
        BlockPos start = null;
        for (int dy = 0; dy <= 1; dy++) {
            BlockPos p = column.up(dy);
            if (isSolid(world, p)) {
                start = p;
                break;
            }
        }
        if (start == null) {
            return null;
        }

        // Walk up the contiguous solid run until air.
        BlockPos top = start;
        int limit = feet.getY() + MAX_REACH;
        while (isSolid(world, top.up())) {
            top = top.up();
            if (top.getY() > limit) {
                return null; // wall too tall to be a ledge
            }
        }
        VoxelShape shape = world.getBlockState(top).getCollisionShape(world, top);
        double topHeight = shape.getMax(Direction.Axis.Y);
        if (topHeight > 1.0) {
            return null; // fences/walls: not a standable surface for a mantle
        }
        double ledgeTopY = top.getY() + topHeight;

        // Does the player's hitbox fit standing on top of the ledge, a bit past the wall plane?
        double forward = 0.3 + ClimbMod.MANTLE_FORWARD_CHECK_DEPTH;
        Box box = player.getBoundingBox().offset(
                facing.getOffsetX() * forward,
                ledgeTopY - player.getY() + 0.01,
                facing.getOffsetZ() * forward);
        boolean room = world.isSpaceEmpty(player, box);

        return new WallHit(start, ledgeTopY, room);
    }

    private static boolean isSolid(World world, BlockPos pos) {
        BlockState state = world.getBlockState(pos);
        return !state.isAir() && !state.getCollisionShape(world, pos).isEmpty();
    }
}
