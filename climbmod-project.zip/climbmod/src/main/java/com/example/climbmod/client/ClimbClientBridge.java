package com.example.climbmod.client;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

import com.example.climbmod.ClimbBridge;
import com.example.climbmod.ClimbEffects;
import com.example.climbmod.ClimbMod;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

/**
 * CLIENT-ONLY implementation of {@link ClimbBridge.Impl}.
 *
 * Server safety: this class is never referenced by common code or common mixins. It is only
 * loaded from {@link ClimbClient} (client entrypoint) and the client-only GameRendererMixin, and
 * is installed into the common {@link ClimbBridge} facade. A dedicated server never loads it.
 */
@Environment(EnvType.CLIENT)
public final class ClimbClientBridge implements ClimbBridge.Impl {

    private static final int SHAKE_DURATION_TICKS = 8;
    private static final float VR_ROLL_SCALE = 0.5F;

    private static final boolean VIVECRAFT_LOADED = FabricLoader.getInstance().isModLoaded("vivecraft");
    /** Vivecraft's "VR is actually running" flag, if this Vivecraft build exposes it. */
    private static final Field VR_RUNNING_FIELD = findVrRunningField();

    private static int shakeTicksLeft;
    private static float shakeStrength;

    // ---------------------------------------------------------------------
    // VR detection
    // ---------------------------------------------------------------------

    private static Field findVrRunningField() {
        if (!VIVECRAFT_LOADED) {
            return null;
        }
        try {
            Field f = Class.forName("org.vivecraft.client_vr.VRState").getField("vrRunning");
            if (f.getType() == boolean.class && Modifier.isStatic(f.getModifiers())) {
                return f;
            }
        } catch (Throwable ignored) {
            // Different Vivecraft version: fall back to "mod loaded".
        }
        return null;
    }

    @Override
    public boolean isVrActive() {
        if (!VIVECRAFT_LOADED) {
            return false;
        }
        if (VR_RUNNING_FIELD == null) {
            return true;
        }
        try {
            return VR_RUNNING_FIELD.getBoolean(null);
        } catch (Throwable t) {
            return true;
        }
    }

    // ---------------------------------------------------------------------
    // Input
    // ---------------------------------------------------------------------

    @Override
    public boolean isLocal(PlayerEntity player) {
        return MinecraftClient.getInstance().player == player;
    }

    @Override
    public boolean isJumpHeld() {
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        return player != null && player.input != null && player.input.jumping;
    }

    @Override
    public boolean isSneakHeld() {
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        return player != null && player.input != null && player.input.sneaking;
    }

    /** Forward (+1) / back (-1) axis as Vivecraft or the keyboard reports it. */
    @Override
    public float getMoveForward() {
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        return player != null && player.input != null ? player.input.movementForward : 0.0F;
    }

    /** Sideways axis; positive = left (vanilla convention). */
    @Override
    public float getMoveSideways() {
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        return player != null && player.input != null ? player.input.movementSideways : 0.0F;
    }

    // ---------------------------------------------------------------------
    // Networking (client -> server)
    // ---------------------------------------------------------------------

    /** Sends a climb event. Skipped when not connected or the server does not have the mod. */
    @Override
    public void sendEvent(ClimbMod.Event event, BlockPos pos) {
        if (MinecraftClient.getInstance().getNetworkHandler() == null
                || !ClientPlayNetworking.canSend(ClimbMod.CLIMB_EVENT)) {
            return;
        }
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeByte(event.ordinal());
        buf.writeBlockPos(pos);
        ClientPlayNetworking.send(ClimbMod.CLIMB_EVENT, buf);
    }

    // ---------------------------------------------------------------------
    // Immediate local feedback (the server rebroadcasts to everyone else)
    // ---------------------------------------------------------------------

    @Override
    public void playLocalFeedback(PlayerEntity player, BlockPos wallPos, ClimbMod.Event event) {
        if (!ClimbEffects.hasEffects(event)) {
            return;
        }
        World world = player.getWorld();
        BlockState state = world.getBlockState(wallPos);
        if (state.isAir()) {
            return;
        }

        // Passing the local player as "source" makes the client play it immediately and locally.
        world.playSound(player, player.getX(), player.getY(), player.getZ(),
                ClimbEffects.soundFor(state, event), SoundCategory.BLOCKS,
                ClimbEffects.volumeFor(state, event), ClimbEffects.pitchFor(state, event));

        Direction facing = player.getHorizontalFacing();
        double x = player.getX() + facing.getOffsetX() * 0.35;
        double y = player.getY() + 1.0;
        double z = player.getZ() + facing.getOffsetZ() * 0.35;
        int count = ClimbEffects.particleCountFor(event);
        for (int i = 0; i < count; i++) {
            double dx = (world.random.nextDouble() - 0.5) * 0.3;
            double dy = (world.random.nextDouble() - 0.5) * 0.3;
            double dz = (world.random.nextDouble() - 0.5) * 0.3;
            world.addParticle(ClimbEffects.particleFor(state), x + dx, y + dy, z + dz,
                    dx * 0.2, 0.05 + dy * 0.2, dz * 0.2);
        }
    }

    // ---------------------------------------------------------------------
    // Camera shake
    // ---------------------------------------------------------------------

    @Override
    public void triggerShake(float strength) {
        if (!ClimbMod.CAMERA_SHAKE_ENABLED) {
            return;
        }
        shakeStrength = strength;
        shakeTicksLeft = SHAKE_DURATION_TICKS;
    }

    public static void resetShake() {
        shakeTicksLeft = 0;
    }

    /** Called once per client tick. */
    public static void tickShake() {
        if (shakeTicksLeft > 0) {
            shakeTicksLeft--;
        }
    }

    /** Camera roll in degrees for this frame: damped sine, two swings over the duration. */
    public static float getShakeRoll(float tickDelta) {
        if (shakeTicksLeft <= 0) {
            return 0.0F;
        }
        float remaining = Math.max(0.0F, shakeTicksLeft - tickDelta);
        float progress = 1.0F - remaining / SHAKE_DURATION_TICKS;
        float roll = (float) Math.sin(progress * Math.PI * 4.0) * (1.0F - progress)
                * ClimbMod.SHAKE_ROLL_DEGREES * shakeStrength;
        return VIVECRAFT_LOADED ? roll * VR_ROLL_SCALE : roll;
    }
}
