package com.example.climbmod;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;

/**
 * Detects the Wither Storm tractor beam. Matches any entity whose registry id has the configured
 * namespace and a path containing the configured text. Defaults: crackerswitherstorm / beam.
 * Override in config/climbmod.properties (created on first run).
 */
public final class BeamDetector {

    public static final double SWIM_ACCEL = 0.08;
    public static final double SWIM_DRAG = 0.90;
    public static final double SWIM_MAX_SPEED = 0.55;
    /** Blocks added around the player's hitbox when testing overlap with a beam entity. */
    private static final double PADDING = 1.0;

    private static final Map<EntityType<?>, Boolean> CACHE = new ConcurrentHashMap<>();
    private static volatile boolean loaded;
    private static volatile String namespace = "crackerswitherstorm";
    private static volatile String contains = "beam";

    private BeamDetector() {
    }

    public static boolean isInBeam(PlayerEntity player) {
        ensureLoaded();
        Box box = player.getBoundingBox().expand(PADDING);
        return !player.getWorld()
                .getEntitiesByClass(Entity.class, box, e -> e != player && isBeam(e.getType()))
                .isEmpty();
    }

    private static boolean isBeam(EntityType<?> type) {
        return CACHE.computeIfAbsent(type, t -> {
            Identifier id = Registries.ENTITY_TYPE.getId(t);
            return id.getNamespace().equals(namespace) && id.getPath().contains(contains);
        });
    }

    private static synchronized void ensureLoaded() {
        if (loaded) {
            return;
        }
        Path file = FabricLoader.getInstance().getConfigDir().resolve("climbmod.properties");
        Properties props = new Properties();
        try {
            if (Files.exists(file)) {
                try (InputStream in = Files.newInputStream(file)) {
                    props.load(in);
                }
            } else {
                props.setProperty("beam_namespace", namespace);
                props.setProperty("beam_path_contains", contains);
                try (OutputStream out = Files.newOutputStream(file)) {
                    props.store(out, "MCSM Movement Engine - beam entity id matching");
                }
            }
        } catch (IOException e) {
            ClimbMod.LOGGER.warn("Could not read/write climbmod.properties, using defaults", e);
        }
        namespace = props.getProperty("beam_namespace", namespace).trim();
        contains = props.getProperty("beam_path_contains", contains).trim();
        CACHE.clear();
        loaded = true;
    }
}
