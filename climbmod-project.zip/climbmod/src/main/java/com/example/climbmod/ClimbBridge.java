package com.example.climbmod;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;

/**
 * Common-side doorway to everything client-only. Contains ZERO client imports, so it is safe to
 * load anywhere. The client entrypoint installs the real implementation; on a dedicated server
 * nothing is ever installed, so every call is a harmless no-op (false / 0 / nothing).
 *
 * Mixins and other common code must call this class, never anything in the .client package.
 */
public final class ClimbBridge {

    /** Implemented by the client-only ClimbClientBridge. Signatures use only common types. */
    public interface Impl {
        boolean isLocal(PlayerEntity player);
        boolean isVrActive();
        boolean isJumpHeld();
        boolean isSneakHeld();
        float getMoveForward();
        float getMoveSideways();
        void sendEvent(ClimbMod.Event event, BlockPos pos);
        void playLocalFeedback(PlayerEntity player, BlockPos wallPos, ClimbMod.Event event);
        void triggerShake(float strength);
    }

    private static volatile Impl impl;

    private ClimbBridge() {
    }

    /** Called once by the client entrypoint. */
    public static void install(Impl implementation) {
        impl = implementation;
    }

    public static boolean isLocal(PlayerEntity player) {
        Impl i = impl;
        return i != null && i.isLocal(player);
    }

    public static boolean isVrActive() {
        Impl i = impl;
        return i != null && i.isVrActive();
    }

    public static boolean isJumpHeld() {
        Impl i = impl;
        return i != null && i.isJumpHeld();
    }

    public static boolean isSneakHeld() {
        Impl i = impl;
        return i != null && i.isSneakHeld();
    }

    public static float getMoveForward() {
        Impl i = impl;
        return i != null ? i.getMoveForward() : 0.0F;
    }

    public static float getMoveSideways() {
        Impl i = impl;
        return i != null ? i.getMoveSideways() : 0.0F;
    }

    public static void sendEvent(ClimbMod.Event event, BlockPos pos) {
        Impl i = impl;
        if (i != null) {
            i.sendEvent(event, pos);
        }
    }

    public static void playLocalFeedback(PlayerEntity player, BlockPos wallPos, ClimbMod.Event event) {
        Impl i = impl;
        if (i != null) {
            i.playLocalFeedback(player, wallPos, event);
        }
    }

    public static void triggerShake(float strength) {
        Impl i = impl;
        if (i != null) {
            i.triggerShake(strength);
        }
    }
}
