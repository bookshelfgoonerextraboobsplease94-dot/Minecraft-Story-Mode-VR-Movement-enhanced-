package com.example.climbmod;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.BlockState;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

/**
 * MCSM Movement & Climbing Engine - common (server + client) entrypoint.
 *
 * Responsibilities:
 *  - Holds every tuning constant so physics/effects can be balanced in one place.
 *  - Receives lightweight "climb event" packets from the controlling client.
 *  - Validates them, keeps a short-lived per-player "is climbing" flag (used to
 *    reset fall distance on the server) and rebroadcasts sound/particles to
 *    OTHER players only (the acting client already played them locally).
 */
public class ClimbMod implements ModInitializer {

    public static final String MOD_ID = "climbmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    /** Client -> server packet channel. Payload: [byte eventId][BlockPos wallBlock]. */
    public static final Identifier CLIMB_EVENT = new Identifier(MOD_ID, "climb_event");

    // ---------------------------------------------------------------------
    // Physics tuning (blocks per tick unless stated otherwise)
    // ---------------------------------------------------------------------

    /** Vertical velocity while latched and NOT holding jump. 0.0 = frozen, -0.05 = slow slide. */
    public static final double LATCH_SLIDE_SPEED = -0.05;
    /** Vertical velocity while latched and holding jump. */
    public static final double ASCENT_SPEED = 0.22;
    /** Max upward speed during the mantle. */
    public static final double MANTLE_UP_SPEED = 0.25;
    /** Forward speed during the mantle. */
    public static final double MANTLE_FORWARD_SPEED = 0.12;
    /** Mantle starts once the player's feet are within this distance below the ledge top. */
    public static final double MANTLE_TRIGGER_BELOW_TOP = 1.0;
    /** Mantle ends once the player's center is this far past the wall plane (and feet are level with the ledge). */
    public static final double MANTLE_COMPLETE_DEPTH = 0.30;
    /** How far forward of the player the standing-room check is done. */
    public static final double MANTLE_FORWARD_CHECK_DEPTH = 0.5;
    /** Gentle push into the wall while latched; keeps horizontalCollision true without drifting. */
    public static final double WALL_PRESS_SPEED = 0.02;
    /** Minimum horizontal speed (pre-collision) needed to latch. */
    public static final double MIN_IMPACT_SPEED = 0.06;

    public static final int RELEASE_COOLDOWN_TICKS = 8;
    public static final int MANTLE_COOLDOWN_TICKS = 6;
    public static final int MAX_MANTLE_TICKS = 20;

    // ---------------------------------------------------------------------
    // Feedback tuning
    // ---------------------------------------------------------------------

    /** Ticks between climbing "step" sounds while ascending. */
    public static final int CLIMB_STEP_INTERVAL = 6;
    /** Client sends a keep-alive this often while latched/mantling. */
    public static final int HEARTBEAT_INTERVAL = 4;
    public static final boolean CAMERA_SHAKE_ENABLED = true;
    /** Peak roll in degrees at strength 1.0. Keep small in VR (comfort). */
    public static final float SHAKE_ROLL_DEGREES = 1.2F;
    public static final float SHAKE_STRENGTH = 1.0F;

    // ---------------------------------------------------------------------
    // Server validation tuning
    // ---------------------------------------------------------------------

    /** Server "climbing" flag lifetime without a refresh (ticks). */
    private static final int SERVER_STATE_TIMEOUT_TICKS = 10;
    /** The reported wall block must be within this many blocks of the player's hitbox. */
    private static final double MAX_WALL_DISTANCE = 1.5;
    /** Minimum ticks between rebroadcast effects for one player (anti-spam). */
    private static final int MIN_EFFECT_INTERVAL_TICKS = 3;

    /** Client-side climbing phase. */
    public enum Phase { NONE, LATCHED, MANTLING }

    /** Event types carried by the climb packet. Order defines the wire id - append only. */
    public enum Event {
        LATCH, STEP, HEARTBEAT, MANTLE, RELEASE;

        private static final Event[] VALUES = values();

        @Nullable
        public static Event fromId(int id) {
            return id >= 0 && id < VALUES.length ? VALUES[id] : null;
        }
    }

    /** Per-player server-side state. Only touched from the server thread (map itself is concurrent for safety). */
    private static final class ServerClimbState {
        long expiresTick;
        long lastEffectTick = Long.MIN_VALUE / 2;
    }

    private static final Map<UUID, ServerClimbState> SERVER_STATES = new ConcurrentHashMap<>();

    @Override
    public void onInitialize() {
        ServerPlayNetworking.registerGlobalReceiver(CLIMB_EVENT, (server, player, handler, buf, responseSender) -> {
            // Read on the network thread, act on the server thread.
            Event event = Event.fromId(buf.readUnsignedByte());
            BlockPos pos = buf.readBlockPos();
            if (event == null) {
                return;
            }
            server.execute(() -> handleClimbEvent(server, player, event, pos));
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) ->
                SERVER_STATES.remove(handler.player.getUuid()));

        LOGGER.info("MCSM Movement & Climbing Engine initialised.");
    }

    /**
     * Validates a client-reported climb event. The server never trusts the reported block:
     * it re-reads the block state itself and checks it is actually next to the player.
     */
    private static void handleClimbEvent(MinecraftServer server, ServerPlayerEntity player, Event event, BlockPos pos) {
        if (!(player.getWorld() instanceof ServerWorld world) || !player.isAlive() || player.isSpectator()) {
            return;
        }

        if (event == Event.RELEASE) {
            SERVER_STATES.remove(player.getUuid());
            return;
        }

        if (!world.isChunkLoaded(pos)) {
            return;
        }
        BlockState state = world.getBlockState(pos);
        if (state.isAir() || state.getCollisionShape(world, pos).isEmpty()) {
            return;
        }
        if (!player.getBoundingBox().expand(MAX_WALL_DISTANCE).intersects(new Box(pos))) {
            return;
        }

        long now = server.getTicks();
        ServerClimbState climbState = SERVER_STATES.computeIfAbsent(player.getUuid(), id -> new ServerClimbState());
        climbState.expiresTick = now + SERVER_STATE_TIMEOUT_TICKS;

        if (!ClimbEffects.hasEffects(event)) {
            return; // heartbeat only
        }
        if (now - climbState.lastEffectTick < MIN_EFFECT_INTERVAL_TICKS) {
            return;
        }
        climbState.lastEffectTick = now;

        ClimbEffects.broadcastToOthers(world, player, pos, state, event);
    }

    /**
     * True while the server believes this player is latched/mantling. Used by the mixin to reset
     * fall distance and the vanilla anti-fly counter on the server side.
     */
    public static boolean isServerClimbing(ServerPlayerEntity player) {
        ServerClimbState state = SERVER_STATES.get(player.getUuid());
        if (state == null) {
            return false;
        }
        MinecraftServer server = player.getServer();
        if (server == null) {
            return false;
        }
        if (server.getTicks() >= state.expiresTick) {
            SERVER_STATES.remove(player.getUuid());
            return false;
        }
        return true;
    }
}
