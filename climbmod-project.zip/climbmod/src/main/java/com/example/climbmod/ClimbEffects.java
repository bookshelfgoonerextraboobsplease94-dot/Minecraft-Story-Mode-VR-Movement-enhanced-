package com.example.climbmod;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/** Sounds and particles for climb events. Pure common code: used by the client (local) and server (rebroadcast). */
public final class ClimbEffects {

    private ClimbEffects() {
    }

    public static boolean hasEffects(ClimbMod.Event event) {
        return event == ClimbMod.Event.LATCH || event == ClimbMod.Event.STEP || event == ClimbMod.Event.MANTLE;
    }

    public static SoundEvent soundFor(BlockState state, ClimbMod.Event event) {
        BlockSoundGroup group = state.getSoundGroup();
        return switch (event) {
            case STEP -> group.getStepSound();
            case MANTLE -> group.getPlaceSound();
            default -> group.getHitSound();
        };
    }

    public static float volumeFor(BlockState state, ClimbMod.Event event) {
        float base = switch (event) {
            case LATCH -> 0.7F;
            case STEP -> 0.5F;
            case MANTLE -> 0.9F;
            default -> 0.0F;
        };
        return base * state.getSoundGroup().getVolume();
    }

    public static float pitchFor(BlockState state, ClimbMod.Event event) {
        float base = event == ClimbMod.Event.MANTLE ? 0.9F : 1.0F;
        return base * state.getSoundGroup().getPitch();
    }

    public static int particleCountFor(ClimbMod.Event event) {
        return switch (event) {
            case LATCH -> 6;
            case STEP -> 3;
            case MANTLE -> 10;
            default -> 0;
        };
    }

    public static ParticleEffect particleFor(BlockState state) {
        return new BlockStateParticleEffect(ParticleTypes.BLOCK, state.isAir() ? Blocks.STONE.getDefaultState() : state);
    }

    /** Server: play sound + particles for everyone EXCEPT the acting player (their client already did it). */
    public static void broadcastToOthers(ServerWorld world, ServerPlayerEntity actor, BlockPos pos,
                                         BlockState state, ClimbMod.Event event) {
        if (!hasEffects(event)) {
            return;
        }
        // With a non-null source the server skips that player.
        world.playSound(actor, actor.getX(), actor.getY(), actor.getZ(), soundFor(state, event),
                SoundCategory.BLOCKS, volumeFor(state, event), pitchFor(state, event));

        Direction facing = actor.getHorizontalFacing();
        double x = actor.getX() + facing.getOffsetX() * 0.35;
        double y = actor.getY() + 1.0;
        double z = actor.getZ() + facing.getOffsetZ() * 0.35;
        ParticleEffect effect = particleFor(state);
        int count = particleCountFor(event);
        for (ServerPlayerEntity viewer : world.getPlayers()) {
            if (viewer != actor) {
                world.spawnParticles(viewer, effect, false, x, y, z, count, 0.15, 0.15, 0.15, 0.05);
            }
        }
    }
}
