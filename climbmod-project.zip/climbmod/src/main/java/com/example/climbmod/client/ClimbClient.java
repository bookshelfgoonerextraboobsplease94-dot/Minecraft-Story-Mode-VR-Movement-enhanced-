package com.example.climbmod.client;

import com.example.climbmod.ClimbBridge;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;

/** Client entrypoint: never runs on a dedicated server. */
@Environment(EnvType.CLIENT)
public class ClimbClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClimbBridge.install(new ClimbClientBridge());
        ClientTickEvents.END_CLIENT_TICK.register(client -> ClimbClientBridge.tickShake());
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> ClimbClientBridge.resetShake());
    }
}
